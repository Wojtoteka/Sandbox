const token = '<TOKEN GO HERE>';

export { token };